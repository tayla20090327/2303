
criaCartao(
    "Álbum", 
    "O rapper Hungria é conhecido por falar sobre carros de luxo e velocidade em muitas de suas músicas. Qual é o nome de um de seus álbuns de grande sucesso que foi lançado em 2013 e ajudou a consolidar sua fama?", 
    "O álbum de grande sucesso de Hungria Hip Hop, lançado em 2013, é "
)

criaCartao(
    "Música", 
   "Qual é o título de uma das canções mais conhecidas de Hungria, que se tornou um grande sucesso e fala sobre memórias e superação?", 
    "Uma das canções mais conhecidas de Hungria, que se tornou um sucesso, é" 
)

criaCartao(
    "Nome",
    "Qual é o nome verdadeiro do cantor Hungria Hip Hop?",
    "O nome verdadeiro dele é Gustavo da Hungria Neves."
)

criaCartao(
    "Mensagem",
    "Qual é a principal mensagem ou tema abordado na letra da música Amor e Fé, um dos seus maiores sucessos?",
    "A principal mensagem da música Amor e Fé é a valorização dos momentos simples da vida ao lado da pessoa amada e a confiança/esperança (fé) para superar os desafios. A letra sugere que com o amor e a fé, é possível viver intensamente e encontrar a felicidade, mesmo nas dificuldades."
)

criaCartao(
    "Curiosidades",
    "Além de cantor, o que mais Hungria faz?",
    "Ele também é produtor musical e empresário."
)

criaCartao(
    "cantor",
    "qual é a idade do cantor de Hungria?",ss
    "34 anos."
)